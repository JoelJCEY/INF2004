C_SRCS += ../lib/libbsp/sysdepend/cpu/rp2040/libbsp_pwm.c
C_DEPS += ./mtkernel_3/lib/libbsp/sysdepend/cpu/rp2040/libbsp_pwm.d
OBJS += ./mtkernel_3/lib/libbsp/sysdepend/cpu/rp2040/libbsp_pwm.o

mtkernel_3/lib/libbsp/sysdepend/cpu/rp2040/%.o: ../lib/libbsp/sysdepend/cpu/rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libbsp/sysdepend/cpu/rp2040/%.o: ../lib/libbsp/sysdepend/cpu/rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
