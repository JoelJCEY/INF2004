C_SRCS += ../lib/libtm/libtm.c
C_DEPS += ./mtkernel_3/lib/libtm/libtm.d
OBJS += ./mtkernel_3/lib/libtm/libtm.o
C_SRCS += ../lib/libtm/libtm_printf.c
C_DEPS += ./mtkernel_3/lib/libtm/libtm_printf.d
OBJS += ./mtkernel_3/lib/libtm/libtm_printf.o

mtkernel_3/lib/libtm/%.o: ../lib/libtm/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libtm/%.o: ../lib/libtm/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
