C_SRCS += ../lib/libtm/sysdepend/pico_rp2040/tm_com.c
C_DEPS += ./mtkernel_3/lib/libtm/sysdepend/pico_rp2040/tm_com.d
OBJS += ./mtkernel_3/lib/libtm/sysdepend/pico_rp2040/tm_com.o

mtkernel_3/lib/libtm/sysdepend/pico_rp2040/%.o: ../lib/libtm/sysdepend/pico_rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libtm/sysdepend/pico_rp2040/%.o: ../lib/libtm/sysdepend/pico_rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
