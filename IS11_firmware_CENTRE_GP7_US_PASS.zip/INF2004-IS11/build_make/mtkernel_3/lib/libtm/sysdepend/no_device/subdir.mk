C_SRCS += ../lib/libtm/sysdepend/no_device/tm_com.c
C_DEPS += ./mtkernel_3/lib/libtm/sysdepend/no_device/tm_com.d
OBJS += ./mtkernel_3/lib/libtm/sysdepend/no_device/tm_com.o

mtkernel_3/lib/libtm/sysdepend/no_device/%.o: ../lib/libtm/sysdepend/no_device/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libtm/sysdepend/no_device/%.o: ../lib/libtm/sysdepend/no_device/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
