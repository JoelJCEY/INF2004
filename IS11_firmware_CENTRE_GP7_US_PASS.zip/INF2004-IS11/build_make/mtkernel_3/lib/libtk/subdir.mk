C_SRCS += ../lib/libtk/fastlock.c
C_DEPS += ./mtkernel_3/lib/libtk/fastlock.d
OBJS += ./mtkernel_3/lib/libtk/fastlock.o
C_SRCS += ../lib/libtk/fastmlock.c
C_DEPS += ./mtkernel_3/lib/libtk/fastmlock.d
OBJS += ./mtkernel_3/lib/libtk/fastmlock.o
C_SRCS += ../lib/libtk/kmalloc.c
C_DEPS += ./mtkernel_3/lib/libtk/kmalloc.d
OBJS += ./mtkernel_3/lib/libtk/kmalloc.o

mtkernel_3/lib/libtk/%.o: ../lib/libtk/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libtk/%.o: ../lib/libtk/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
