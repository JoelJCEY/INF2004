C_SRCS += ../lib/libtk/sysdepend/cpu/core/armv6m/int_armv6m.c
C_DEPS += ./mtkernel_3/lib/libtk/sysdepend/cpu/core/armv6m/int_armv6m.d
OBJS += ./mtkernel_3/lib/libtk/sysdepend/cpu/core/armv6m/int_armv6m.o
C_SRCS += ../lib/libtk/sysdepend/cpu/core/armv6m/wusec_armv6m.c
C_DEPS += ./mtkernel_3/lib/libtk/sysdepend/cpu/core/armv6m/wusec_armv6m.d
OBJS += ./mtkernel_3/lib/libtk/sysdepend/cpu/core/armv6m/wusec_armv6m.o

mtkernel_3/lib/libtk/sysdepend/cpu/core/armv6m/%.o: ../lib/libtk/sysdepend/cpu/core/armv6m/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libtk/sysdepend/cpu/core/armv6m/%.o: ../lib/libtk/sysdepend/cpu/core/armv6m/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
