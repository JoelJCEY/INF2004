C_SRCS += ../lib/libtk/sysdepend/cpu/rp2040/int_rp2040.c
C_DEPS += ./mtkernel_3/lib/libtk/sysdepend/cpu/rp2040/int_rp2040.d
OBJS += ./mtkernel_3/lib/libtk/sysdepend/cpu/rp2040/int_rp2040.o
C_SRCS += ../lib/libtk/sysdepend/cpu/rp2040/ptimer_rp2040.c
C_DEPS += ./mtkernel_3/lib/libtk/sysdepend/cpu/rp2040/ptimer_rp2040.d
OBJS += ./mtkernel_3/lib/libtk/sysdepend/cpu/rp2040/ptimer_rp2040.o

mtkernel_3/lib/libtk/sysdepend/cpu/rp2040/%.o: ../lib/libtk/sysdepend/cpu/rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/lib/libtk/sysdepend/cpu/rp2040/%.o: ../lib/libtk/sysdepend/cpu/rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
