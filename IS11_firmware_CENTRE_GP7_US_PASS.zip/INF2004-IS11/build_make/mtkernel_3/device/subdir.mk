C_SRCS += ../device/common/drvif/msdrvif.c
C_DEPS += ./mtkernel_3/device/common/drvif/msdrvif.d
OBJS += ./mtkernel_3/device/common/drvif/msdrvif.o
C_SRCS += ../device/ser/ser.c
C_DEPS += ./mtkernel_3/device/ser/ser.d
OBJS += ./mtkernel_3/device/ser/ser.o
C_SRCS += ../device/i2c/i2c.c
C_DEPS += ./mtkernel_3/device/i2c/i2c.d
OBJS += ./mtkernel_3/device/i2c/i2c.o
C_SRCS += ../device/adc/adc.c
C_DEPS += ./mtkernel_3/device/adc/adc.d
OBJS += ./mtkernel_3/device/adc/adc.o
C_SRCS += ../device/adc/sysdepend/rp2040/adc_rp2040.c
C_DEPS += ./mtkernel_3/device/adc/sysdepend/rp2040/adc_rp2040.d
OBJS += ./mtkernel_3/device/adc/sysdepend/rp2040/adc_rp2040.o
C_SRCS += ../device/i2c/sysdepend/rp2040/i2c_rp2040.c
C_DEPS += ./mtkernel_3/device/i2c/sysdepend/rp2040/i2c_rp2040.d
OBJS += ./mtkernel_3/device/i2c/sysdepend/rp2040/i2c_rp2040.o
C_SRCS += ../device/ser/sysdepend/rp2040/ser_rp2040.c
C_DEPS += ./mtkernel_3/device/ser/sysdepend/rp2040/ser_rp2040.d
OBJS += ./mtkernel_3/device/ser/sysdepend/rp2040/ser_rp2040.o

mtkernel_3/device/adc/%.o: ../device/adc/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/adc/%.o: ../device/adc/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/adc/sysdepend/rp2040/%.o: ../device/adc/sysdepend/rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/adc/sysdepend/rp2040/%.o: ../device/adc/sysdepend/rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/common/drvif/%.o: ../device/common/drvif/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/common/drvif/%.o: ../device/common/drvif/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/i2c/%.o: ../device/i2c/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/i2c/%.o: ../device/i2c/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/i2c/sysdepend/rp2040/%.o: ../device/i2c/sysdepend/rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/i2c/sysdepend/rp2040/%.o: ../device/i2c/sysdepend/rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/ser/%.o: ../device/ser/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/ser/%.o: ../device/ser/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/ser/sysdepend/rp2040/%.o: ../device/ser/sysdepend/rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/device/ser/sysdepend/rp2040/%.o: ../device/ser/sysdepend/rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
