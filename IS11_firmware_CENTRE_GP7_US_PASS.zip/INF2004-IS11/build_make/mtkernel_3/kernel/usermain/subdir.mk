C_SRCS += ../kernel/usermain/usermain.c
C_DEPS += ./mtkernel_3/kernel/usermain/usermain.d
OBJS += ./mtkernel_3/kernel/usermain/usermain.o

mtkernel_3/kernel/usermain/%.o: ../kernel/usermain/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/usermain/%.o: ../kernel/usermain/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
