C_SRCS += ../kernel/inittask/inittask.c
C_DEPS += ./mtkernel_3/kernel/inittask/inittask.d
OBJS += ./mtkernel_3/kernel/inittask/inittask.o

mtkernel_3/kernel/inittask/%.o: ../kernel/inittask/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/inittask/%.o: ../kernel/inittask/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
