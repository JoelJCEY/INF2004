C_SRCS += ../kernel/tstdlib/bitop.c
C_DEPS += ./mtkernel_3/kernel/tstdlib/bitop.d
OBJS += ./mtkernel_3/kernel/tstdlib/bitop.o
C_SRCS += ../kernel/tstdlib/string.c
C_DEPS += ./mtkernel_3/kernel/tstdlib/string.d
OBJS += ./mtkernel_3/kernel/tstdlib/string.o

mtkernel_3/kernel/tstdlib/%.o: ../kernel/tstdlib/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/tstdlib/%.o: ../kernel/tstdlib/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
