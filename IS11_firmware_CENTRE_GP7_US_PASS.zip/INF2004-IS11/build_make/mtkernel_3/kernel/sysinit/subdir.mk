C_SRCS += ../kernel/sysinit/sysinit.c
C_DEPS += ./mtkernel_3/kernel/sysinit/sysinit.d
OBJS += ./mtkernel_3/kernel/sysinit/sysinit.o

mtkernel_3/kernel/sysinit/%.o: ../kernel/sysinit/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/sysinit/%.o: ../kernel/sysinit/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
