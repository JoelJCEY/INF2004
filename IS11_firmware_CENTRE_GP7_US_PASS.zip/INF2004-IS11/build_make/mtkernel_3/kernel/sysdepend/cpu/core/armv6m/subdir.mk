C_SRCS += ../kernel/sysdepend/cpu/core/armv6m/cpu_cntl.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/cpu_cntl.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/cpu_cntl.o
S_UPPER_SRCS += ../kernel/sysdepend/cpu/core/armv6m/dispatch.S
S_UPPER_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/dispatch.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/dispatch.o
C_SRCS += ../kernel/sysdepend/cpu/core/armv6m/exc_hdr.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/exc_hdr.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/exc_hdr.o
C_SRCS += ../kernel/sysdepend/cpu/core/armv6m/interrupt.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/interrupt.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/interrupt.o
C_SRCS += ../kernel/sysdepend/cpu/core/armv6m/reset_hdl.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/reset_hdl.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/core/armv6m/reset_hdl.o

mtkernel_3/kernel/sysdepend/cpu/core/armv6m/%.o: ../kernel/sysdepend/cpu/core/armv6m/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/sysdepend/cpu/core/armv6m/%.o: ../kernel/sysdepend/cpu/core/armv6m/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
