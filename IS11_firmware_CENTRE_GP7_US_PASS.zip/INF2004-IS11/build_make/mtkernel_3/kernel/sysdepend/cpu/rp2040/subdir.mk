C_SRCS += ../kernel/sysdepend/cpu/rp2040/boot_2nd.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/boot_2nd.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/boot_2nd.o
C_SRCS += ../kernel/sysdepend/cpu/rp2040/smp_atomic.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/smp_atomic.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/smp_atomic.o
C_SRCS += ../kernel/sysdepend/cpu/rp2040/smp_rp2040.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/smp_rp2040.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/smp_rp2040.o
C_SRCS += ../kernel/sysdepend/cpu/rp2040/vector_tbl.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/vector_tbl.d
OBJS += ./mtkernel_3/kernel/sysdepend/cpu/rp2040/vector_tbl.o

mtkernel_3/kernel/sysdepend/cpu/rp2040/%.o: ../kernel/sysdepend/cpu/rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/sysdepend/cpu/rp2040/%.o: ../kernel/sysdepend/cpu/rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
