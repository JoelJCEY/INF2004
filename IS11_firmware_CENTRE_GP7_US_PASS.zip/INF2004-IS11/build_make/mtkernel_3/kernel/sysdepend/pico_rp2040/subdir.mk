C_SRCS += ../kernel/sysdepend/pico_rp2040/cpu_clock.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/cpu_clock.d
OBJS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/cpu_clock.o
C_SRCS += ../kernel/sysdepend/pico_rp2040/devinit.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/devinit.d
OBJS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/devinit.o
C_SRCS += ../kernel/sysdepend/pico_rp2040/hw_setting.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/hw_setting.d
OBJS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/hw_setting.o
C_SRCS += ../kernel/sysdepend/pico_rp2040/power_save.c
C_DEPS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/power_save.d
OBJS += ./mtkernel_3/kernel/sysdepend/pico_rp2040/power_save.o

mtkernel_3/kernel/sysdepend/pico_rp2040/%.o: ../kernel/sysdepend/pico_rp2040/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/kernel/sysdepend/pico_rp2040/%.o: ../kernel/sysdepend/pico_rp2040/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
