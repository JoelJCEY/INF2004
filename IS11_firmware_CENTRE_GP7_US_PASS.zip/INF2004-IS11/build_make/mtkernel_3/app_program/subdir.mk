C_SRCS += ../app_program/app_log.c
C_DEPS += ./mtkernel_3/app_program/app_log.d
OBJS += ./mtkernel_3/app_program/app_log.o
C_SRCS += ../app_program/app_main.c
C_DEPS += ./mtkernel_3/app_program/app_main.d
OBJS += ./mtkernel_3/app_program/app_main.o
C_SRCS += ../app_program/sensor_bench.c
C_DEPS += ./mtkernel_3/app_program/sensor_bench.d
OBJS += ./mtkernel_3/app_program/sensor_bench.o
C_SRCS += ../app_program/subsystem1/comms_bridge.c
C_DEPS += ./mtkernel_3/app_program/subsystem1/comms_bridge.d
OBJS += ./mtkernel_3/app_program/subsystem1/comms_bridge.o
C_SRCS += ../app_program/subsystem1/subsystem1.c
C_DEPS += ./mtkernel_3/app_program/subsystem1/subsystem1.d
OBJS += ./mtkernel_3/app_program/subsystem1/subsystem1.o
C_SRCS += ../app_program/subsystem1/subsystem1_test.c
C_DEPS += ./mtkernel_3/app_program/subsystem1/subsystem1_test.d
OBJS += ./mtkernel_3/app_program/subsystem1/subsystem1_test.o
C_SRCS += ../app_program/subsystem1/task_comms.c
C_DEPS += ./mtkernel_3/app_program/subsystem1/task_comms.d
OBJS += ./mtkernel_3/app_program/subsystem1/task_comms.o
C_SRCS += ../app_program/subsystem1/telemetry_codec.c
C_DEPS += ./mtkernel_3/app_program/subsystem1/telemetry_codec.d
OBJS += ./mtkernel_3/app_program/subsystem1/telemetry_codec.o
C_SRCS += ../app_program/subsystem2/drv_encoder.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/drv_encoder.d
OBJS += ./mtkernel_3/app_program/subsystem2/drv_encoder.o
C_SRCS += ../app_program/subsystem2/drv_motor.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/drv_motor.d
OBJS += ./mtkernel_3/app_program/subsystem2/drv_motor.o
C_SRCS += ../app_program/subsystem2/motion_api.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/motion_api.d
OBJS += ./mtkernel_3/app_program/subsystem2/motion_api.o
C_SRCS += ../app_program/subsystem2/motion_ctrl.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/motion_ctrl.d
OBJS += ./mtkernel_3/app_program/subsystem2/motion_ctrl.o
C_SRCS += ../app_program/subsystem2/subsystem2.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/subsystem2.d
OBJS += ./mtkernel_3/app_program/subsystem2/subsystem2.o
C_SRCS += ../app_program/subsystem2/subsystem2_test.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/subsystem2_test.d
OBJS += ./mtkernel_3/app_program/subsystem2/subsystem2_test.o
C_SRCS += ../app_program/subsystem2/task_motion.c
C_DEPS += ./mtkernel_3/app_program/subsystem2/task_motion.d
OBJS += ./mtkernel_3/app_program/subsystem2/task_motion.o
C_SRCS += ../app_program/subsystem3/drv_ir_adc.c
C_DEPS += ./mtkernel_3/app_program/subsystem3/drv_ir_adc.d
OBJS += ./mtkernel_3/app_program/subsystem3/drv_ir_adc.o
C_SRCS += ../app_program/subsystem3/line_sense.c
C_DEPS += ./mtkernel_3/app_program/subsystem3/line_sense.d
OBJS += ./mtkernel_3/app_program/subsystem3/line_sense.o
C_SRCS += ../app_program/subsystem3/subsystem3.c
C_DEPS += ./mtkernel_3/app_program/subsystem3/subsystem3.d
OBJS += ./mtkernel_3/app_program/subsystem3/subsystem3.o
C_SRCS += ../app_program/subsystem3/subsystem3_test.c
C_DEPS += ./mtkernel_3/app_program/subsystem3/subsystem3_test.d
OBJS += ./mtkernel_3/app_program/subsystem3/subsystem3_test.o
C_SRCS += ../app_program/subsystem3/task_line.c
C_DEPS += ./mtkernel_3/app_program/subsystem3/task_line.d
OBJS += ./mtkernel_3/app_program/subsystem3/task_line.o
C_SRCS += ../app_program/subsystem4/drv_i2c0.c
C_DEPS += ./mtkernel_3/app_program/subsystem4/drv_i2c0.d
OBJS += ./mtkernel_3/app_program/subsystem4/drv_i2c0.o
C_SRCS += ../app_program/subsystem4/drv_lsm303.c
C_DEPS += ./mtkernel_3/app_program/subsystem4/drv_lsm303.d
OBJS += ./mtkernel_3/app_program/subsystem4/drv_lsm303.o
C_SRCS += ../app_program/subsystem4/hump.c
C_DEPS += ./mtkernel_3/app_program/subsystem4/hump.d
OBJS += ./mtkernel_3/app_program/subsystem4/hump.o
C_SRCS += ../app_program/subsystem4/subsystem4.c
C_DEPS += ./mtkernel_3/app_program/subsystem4/subsystem4.d
OBJS += ./mtkernel_3/app_program/subsystem4/subsystem4.o
C_SRCS += ../app_program/subsystem4/subsystem4_test.c
C_DEPS += ./mtkernel_3/app_program/subsystem4/subsystem4_test.d
OBJS += ./mtkernel_3/app_program/subsystem4/subsystem4_test.o
C_SRCS += ../app_program/subsystem4/task_imu.c
C_DEPS += ./mtkernel_3/app_program/subsystem4/task_imu.d
OBJS += ./mtkernel_3/app_program/subsystem4/task_imu.o
C_SRCS += ../app_program/subsystem5/ctrl_logic.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/ctrl_logic.d
OBJS += ./mtkernel_3/app_program/subsystem5/ctrl_logic.o
C_SRCS += ../app_program/subsystem5/drv_indicators.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/drv_indicators.d
OBJS += ./mtkernel_3/app_program/subsystem5/drv_indicators.o
C_SRCS += ../app_program/subsystem5/drv_neopixel_pio.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/drv_neopixel_pio.d
OBJS += ./mtkernel_3/app_program/subsystem5/drv_neopixel_pio.o
C_SRCS += ../app_program/subsystem5/drv_servo.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/drv_servo.d
OBJS += ./mtkernel_3/app_program/subsystem5/drv_servo.o
C_SRCS += ../app_program/subsystem5/drv_ultrasonic.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/drv_ultrasonic.d
OBJS += ./mtkernel_3/app_program/subsystem5/drv_ultrasonic.o
C_SRCS += ../app_program/subsystem5/scan_profile.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/scan_profile.d
OBJS += ./mtkernel_3/app_program/subsystem5/scan_profile.o
C_SRCS += ../app_program/subsystem5/subsystem5.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/subsystem5.d
OBJS += ./mtkernel_3/app_program/subsystem5/subsystem5.o
C_SRCS += ../app_program/subsystem5/subsystem5_test.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/subsystem5_test.d
OBJS += ./mtkernel_3/app_program/subsystem5/subsystem5_test.o
C_SRCS += ../app_program/subsystem5/task_ctrl.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/task_ctrl.d
OBJS += ./mtkernel_3/app_program/subsystem5/task_ctrl.o
C_SRCS += ../app_program/subsystem5/task_scan.c
C_DEPS += ./mtkernel_3/app_program/subsystem5/task_scan.d
OBJS += ./mtkernel_3/app_program/subsystem5/task_scan.o
C_SRCS += ../app_program/us_diag.c
C_DEPS += ./mtkernel_3/app_program/us_diag.d
OBJS += ./mtkernel_3/app_program/us_diag.o

mtkernel_3/app_program/%.o: ../app_program/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/%.o: ../app_program/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem1/%.o: ../app_program/subsystem1/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem1/%.o: ../app_program/subsystem1/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem2/%.o: ../app_program/subsystem2/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem2/%.o: ../app_program/subsystem2/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem3/%.o: ../app_program/subsystem3/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem3/%.o: ../app_program/subsystem3/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem4/%.o: ../app_program/subsystem4/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem4/%.o: ../app_program/subsystem4/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem5/%.o: ../app_program/subsystem5/%.c
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(GCC) $(CFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

mtkernel_3/app_program/subsystem5/%.o: ../app_program/subsystem5/%.S
	@echo 'Building file: $<'
	@mkdir -p "$(@D)"
	$(AS) $(ASFLAGS) -D$(TARGET) $(INCPATH) -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"
