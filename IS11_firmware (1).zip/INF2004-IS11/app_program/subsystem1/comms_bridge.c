/*
 *	comms_bridge.c
 *	Subsystem 1 -- code that runs inside the kernel's Wi-Fi service task
 *	(called from mqtt_utk.c).  TMO_POL only; no mutex is ever taken.
 */

#include "subsystem1.h"
#include "comms_bridge.h"
#include "../subsystem5/subsystem5.h"	/* IF-03 mbf_remote, flg_sys */
#include "../subsystem3/subsystem3.h"	/* live IR values */
#include "../subsystem5/scan_profile.h"	/* SCAN_POSITIONS */

EXPORT volatile UW comms_mqtt_connected;	/* writer: Wi-Fi task (bridge) */
EXPORT volatile UW comms_rx_rejected;

int comms_bridge_take_frame(unsigned char *buf, int max)
{
	UB	frame[WIRE_TLM_LEN];
	INT	n;
	INT	i;

	if ((mbf_outbox <= 0) || (max < WIRE_TLM_LEN)) {
		return 0;
	}
	n = tk_rcv_mbf(mbf_outbox, frame, TMO_POL);
	if (n <= 0) {
		return 0;
	}
	for (i = 0; i < n; i++) {
		buf[i] = frame[i];
	}
	return (int)n;
}

void comms_bridge_on_command(const unsigned char *data, int len)
{
	REMOTE_MSG	m;

	if ((mbf_remote <= 0) || (comms_decode_cmd(data, (INT)len, &m) != E_OK)) {
		comms_rx_rejected++;
		app_log((UB*)"comms: command rejected (len %d)\n", len);
		return;
	}
	/* STOP is the latency-critical message: forwarded at once, from
	   here, without waiting for comms_task's next cycle (6.1) */
	if (tk_snd_mbf(mbf_remote, &m, sizeof(m), TMO_POL) < E_OK) {
		comms_rx_rejected++;
		return;
	}
	(void)tk_set_flg(flg_sys, EVF_REMOTE);
}

void comms_bridge_set_connected(int connected)
{
	comms_mqtt_connected = (connected != 0) ? 1U : 0U;
}

/* Dashboard log (is11/car/log): oldest line first, removed only after
   MQTT accepted it, so nothing is lost while the link is down. */
int comms_bridge_peek_log(unsigned char *buf, int max)
{
	return (int)app_log_peek((UB*)buf, (INT)max);
}

void comms_bridge_pop_log(void)
{
	app_log_pop();
}

/* Live IR snapshot for the dashboard (is11/car/ir, 10 Hz):
   "rawL rawC rawR normL normC normR err" */
int comms_bridge_ir_text(unsigned char *buf, int max)
{
	if (max < 64) {
		return 0;
	}
	return (int)tm_sprintf((UB*)buf, (const UB*)"%d %d %d %d %d %d %d",
			       (INT)line_raw_avg[0], (INT)line_raw_avg[1], (INT)line_raw_avg[2],
			       (INT)line_norm[0], (INT)line_norm[1], (INT)line_norm[2],
			       (INT)line_unpack_err(line_latest));
}

/* Live ultrasonic for the dashboard (is11/car/us, 10 Hz):
   "state servo_deg mm"  state: 0 idle 1 watching 2 paused on hump
   3 coarse sweep 4 fine sweep 5 guard; mm 0 = no echo, 1000 = far */
int comms_bridge_us_text(unsigned char *buf, int max)
{
	UW	w = scan_status_word;

	if (max < 32) {
		return 0;
	}
	return (int)tm_sprintf((UB*)buf, (const UB*)"%d %d %d",
			       (INT)((w >> 5) & 0x7U),
			       (INT)SERVO_IDX_TO_DEG(w & 0x1FU),
			       (INT)((w >> 16) & 0x1FFFU));
}

/* Last sweep, only when a new one is ready (is11/car/sweep):
   "seq d30 d35 ... d150" */
int comms_bridge_sweep_text(unsigned char *buf, int max)
{
	static UW	sent = 0;
	UW		seq = scan_sweep_seq;
	INT		n;
	INT		i;

	if ((seq == sent) || (max < (SCAN_POSITIONS * 6 + 12))) {
		return 0;
	}
	sent = seq;
	n = tm_sprintf((UB*)buf, (const UB*)"%d", (INT)seq);
	for (i = 0; i < SCAN_POSITIONS; i++) {
		n += tm_sprintf((UB*)&buf[n], (const UB*)" %d", (INT)scan_last_sweep[i]);
	}
	return (int)n;
}
