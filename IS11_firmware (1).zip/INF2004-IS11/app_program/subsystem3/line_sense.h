/*
 *	line_sense.h
 *	Subsystem 3 -- pure line and barcode logic (no hardware, no kernel
 *	calls), unit-tested in subsystem3_test.c.
 */

#ifndef LINE_SENSE_H
#define LINE_SENSE_H

#include "subsystem3.h"

/* ---------------------------------------------------------------------
 *  Calibration and normalisation (12-bit raw -> 0..1000, 1000 = black)
 *  Defaults are ESTIMATES (a past INF2004 car read white below ~1800 and
 *  black above it on a 12-bit ADC): replace with the A3 logs from the mat.
 *  The start-up calibration sweep overwrites them when contrast is good.
 * --------------------------------------------------------------------- */
/* 1 = print raw and normalised IR values every 500 ms (bring-up, S3-M01).
   Set to 0 once the thresholds are set. */
#define LINE_DIAG		1

#define LINE_BLACK_IS_HIGH	1	/* analogue IR modules: black = high V */
#define LINE_DEF_WHITE		250	/* measured 26 Oct: white 130-250    */
#define LINE_DEF_BLACK		3700	/* measured 26 Oct: black 3600-4060  */
#define LINE_MIN_CONTRAST	300	/* raw counts between black and white (was 800;
					   lowered 28 Oct so a weak centre sensor is
					   scaled up instead of ignored) */

typedef struct {
	UH	white[3];	/* IR_L, IR_C, IR_R */
	UH	black[3];
} LINE_CAL;

IMPORT void line_cal_defaults(LINE_CAL *cal);
IMPORT INT  line_normalise(const LINE_CAL *cal, UINT ch, INT raw);

/* Line error from IR_L and IR_C only (FR1).  n_l, n_c: 0..1000.
   Returns -1000..+1000 (> 0: line to the left).  *on_line is TRUE when
   either sensor sees black. */
#define LINE_BLACK_N		400	/* hysteresis: black above ... (was 600, lowered 28 Oct) */
#define LINE_WHITE_N		250	/* ... white below (was 400)    */
IMPORT INT  line_error(INT n_l, INT n_c, INT n_r, BOOL *on_line);

/* ---------------------------------------------------------------------
 *  Code 39 (design 6.3, VA2): 29 elements = '*' X '*' with two
 *  inter-character gaps.  Wide/narrow by relative width (~3:1), so the
 *  exact speed does not matter; tried forwards then backwards.
 * --------------------------------------------------------------------- */
#define CODE39_ELEMENTS		29
#define CODE39_MIN_RATIO_X10	15	/* narrowest wide >= 1.5 x widest narrow */

#define C39_OK			0
#define C39_ERR_COUNT		(-1)	/* not 29 elements      */
#define C39_ERR_RATIO		(-2)	/* wide/narrow unclear  */
#define C39_ERR_STARTSTOP	(-3)	/* no '*' at both ends  */
#define C39_ERR_CHAR		(-4)	/* not in the table     */

IMPORT INT  code39_decode(const UW *widths, INT n, UB *letter);
IMPORT BARCODE_CMD line_letter_to_cmd(UB letter);

/* ---------------------------------------------------------------------
 *  Barcode reader state machine (statechart 6.3), fed one IR_R sample
 *  at a time (1 kHz).  Widths are measured in µm travelled, using the
 *  encoder speed (at 1 kHz, µm per sample = mm/s).
 * --------------------------------------------------------------------- */
#define BC_MAX_ELEMENTS		40
#define BC_QUIET_MIN_UM		12000U	/* white needed before and after   */
#define BC_JUNCTION_MIN_UM	16000U	/* single stripe wider than any bar */
#define BC_REPEAT_IGNORE_MM	200U	/* same barcode ignored for 200 mm */
#define BC_MAX_SAMPLES		3000U	/* > 3 s inside a read: reject      */

typedef enum {
	BCS_WAIT_GAP	= 0,	/* WAITING FOR BARCODE (needs quiet zone) */
	BCS_ARMED	= 1,	/* quiet zone seen, waiting for a bar     */
	BCS_READING	= 2	/* READING BARS                            */
} BC_STATE;

typedef enum {
	BCR_NONE	= 0,
	BCR_BARCODE	= 1,	/* letter valid                 */
	BCR_JUNCTION	= 2,	/* single wide stripe           */
	BCR_REJECT	= 3	/* reason valid                 */
} BC_RESULT;

typedef struct {
	BC_STATE	state;
	BOOL		black;		/* hysteresis level            */
	UW		run_um;		/* current run length          */
	UW		widths[BC_MAX_ELEMENTS];
	INT		n;
	UW		max_um;
	UW		samples;
	BOOL		overflow;
} BC_READER;

IMPORT void      bc_reader_reset(BC_READER *r);
/* n_r: normalised IR_R 0..1000.  um: distance for this sample. */
IMPORT BC_RESULT bc_reader_feed(BC_READER *r, INT n_r, UW um,
				UB *letter, INT *reason);

#endif /* LINE_SENSE_H */
