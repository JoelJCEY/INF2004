/*
 *	subsystem3_test.c
 *	On-target tests for subsystem 3 (Line & Barcode).  make TEST=1
 *	Record results in testing/subsystem3/TEST_LOG.md.
 *
 *	S3-U01..U07 feed synthetic data to the pure logic in line_sense.c.
 *	Barcode passes on the real mat (A3: 20 passes per barcode, both
 *	directions, >= 95%) are manual tests, see TEST_LOG.md.
 */

#include "subsystem3.h"
#include "line_sense.h"
#include "drv_ir_adc.h"
#include "../test_report.h"

#if APP_TEST

#define NARROW_UM	3000U
#define WIDE_UM		9000U

/* Build the 29 widths of "*<c>*" from 9-bit patterns (bit 8 first) */
LOCAL void build_symbol(UH pat_mid, UW *w)
{
	const UH pats[3] = { 0x094, pat_mid, 0x094 };	/* '*' X '*' */
	INT	k, i, n = 0;

	for (k = 0; k < 3; k++) {
		for (i = 8; i >= 0; i--) {
			w[n++] = ((pats[k] >> i) & 1U) ? WIDE_UM : NARROW_UM;
		}
		if (k < 2) {
			w[n++] = NARROW_UM;	/* inter-character gap */
		}
	}
}

/* Feed a run of one level to the reader, 1 sample = um µm */
LOCAL BC_RESULT feed_run(BC_READER *r, BOOL black, UW len_um, UW um,
			 UB *letter, INT *reason)
{
	BC_RESULT	res = BCR_NONE;
	BC_RESULT	x;
	UW		d;

	for (d = 0; d < len_um; d += um) {
		x = bc_reader_feed(r, black ? 1000 : 0, um, letter, reason);
		if (x != BCR_NONE) {
			res = x;
		}
	}
	return res;
}

EXPORT void subsystem3_test(void)
{
	UW		w[CODE39_ELEMENTS];
	UW		rev[CODE39_ELEMENTS];
	UB		letter = 0;
	INT		i, reason = 0;
	BOOL		on_line;
	BC_READER	r;
	BC_RESULT	res;
	UW		wr1, wr2;

	TEST_INIT();

	/* S3-U01: '*A*' decodes forwards */
	build_symbol(0x109, w);
	TEST_CHECK("S3-U01", (code39_decode(w, CODE39_ELEMENTS, &letter) == C39_OK)
		   && (letter == 'A'), "Code 39 '*A*' forwards");

	/* S3-U02: the same symbol read backwards (U-turn, reverse pass) */
	for (i = 0; i < CODE39_ELEMENTS; i++) {
		rev[i] = w[CODE39_ELEMENTS - 1 - i];
	}
	letter = 0;
	TEST_CHECK("S3-U02", (code39_decode(rev, CODE39_ELEMENTS, &letter) == C39_OK)
		   && (letter == 'A'), "Code 39 '*A*' backwards");

	/* S3-U03: a partial read (28 elements) is rejected (VA2) */
	TEST_CHECK("S3-U03", code39_decode(w, 28, &letter) == C39_ERR_COUNT,
		   "28-element read rejected");

	/* S3-U04: letters map to commands; unknown letters continue straight */
	TEST_CHECK("S3-U04", (line_letter_to_cmd('A') == BC_TURN_LEFT) &&
		   (line_letter_to_cmd('D') == BC_U_TURN) &&
		   (line_letter_to_cmd('F') == BC_UNRECOGNISED),
		   "letter-to-command mapping (FR2)");

	/* S3-U05: whole reader at 300 mm/s (300 µm per sample): quiet zone,
	   '*Z*', quiet zone -> one barcode, no reject */
	bc_reader_reset(&r);
	build_symbol(0x0D0, w);
	res = feed_run(&r, FALSE, 20000U, 300U, &letter, &reason);
	for (i = 0; i < CODE39_ELEMENTS; i++) {
		BC_RESULT x = feed_run(&r, (i % 2) == 0, w[i], 300U, &letter, &reason);
		if (x != BCR_NONE) res = x;
	}
	letter = 0;
	res = feed_run(&r, FALSE, 30000U, 300U, &letter, &reason);
	TEST_CHECK("S3-U05", (res == BCR_BARCODE) && (letter == 'Z'),
		   "reader decodes '*Z*' from 1 kHz samples");

	/* S3-U06: an 18 mm stripe with white both sides is a junction,
	   not a wide bar (F3, A3) */
	bc_reader_reset(&r);
	(void)feed_run(&r, FALSE, 20000U, 300U, &letter, &reason);
	(void)feed_run(&r, TRUE, 18000U, 300U, &letter, &reason);
	res = feed_run(&r, FALSE, 40000U, 300U, &letter, &reason);
	TEST_CHECK("S3-U06", res == BCR_JUNCTION, "18 mm single stripe -> junction");

	/* S3-U07: line error sign convention (IF-08) */
	TEST_CHECK("S3-U07a", line_error(900, 200, 0, &on_line) > 0 && on_line,
		   "IR_L black -> error > 0 (line to the left)");
	TEST_CHECK("S3-U07b", line_error(0, 0, 1000, &on_line) < 0 && on_line,
		   "only IR_R black -> error < 0 (steer right)");
	TEST_CHECK("S3-U07d", line_error(0, 1000, 0, &on_line) == 0 && on_line,
		   "only IR_C black -> error 0 (straight)");
	TEST_CHECK("S3-U07f", line_error(0, 1000, 1000, &on_line) < 0 && on_line,
		   "IR_C + IR_R black -> gentle right");
	(void)line_error(0, 300, 100, &on_line);
	TEST_CHECK("S3-U07e", !on_line, "all below black -> not on the line (keep last side)");
	TEST_CHECK("S3-U07c", line_unpack_err(line_pack(-1000, LINE_F_VALID, 1234)) == -1000,
		   "line word packs -1000 losslessly");

	/* S3-U08: DMA ring keeps advancing (hardware sampling alive) */
	wr1 = drv_ir_adc_write_index();
	tk_dly_tsk(30);
	wr2 = drv_ir_adc_write_index();
	TEST_CHECK("S3-U08", wr1 != wr2, "DMA ring write index advances");

	tm_printf((UB*)"[TEST] S3 info: line word 0x%08x, reads %d ok / %d rejected\n",
		  line_latest, line_read_stats & 0xFFFFU, line_read_stats >> 16);

	TEST_SUMMARY("subsystem3");
}

#endif /* APP_TEST */
