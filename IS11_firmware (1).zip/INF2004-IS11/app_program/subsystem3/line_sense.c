/*
 *	line_sense.c
 *	Subsystem 3 -- line error, Code 39 decoding and the barcode reader.
 */

#include "line_sense.h"

/* ---------------------------------------------------------------------
 *  Calibration
 * --------------------------------------------------------------------- */
EXPORT void line_cal_defaults(LINE_CAL *cal)
{
	UINT	i;

	for (i = 0; i < 3U; i++) {
		cal->white[i] = LINE_DEF_WHITE;
		cal->black[i] = LINE_DEF_BLACK;
	}
}

EXPORT INT line_normalise(const LINE_CAL *cal, UINT ch, INT raw)
{
	INT	w = (INT)cal->white[ch];
	INT	b = (INT)cal->black[ch];
	INT	n;

	if (b == w) {
		return 0;
	}
#if LINE_BLACK_IS_HIGH
	n = ((raw - w) * 1000) / (b - w);
#else
	n = ((w - raw) * 1000) / (w - b);
#endif
	return APP_CLAMP(n, 0, 1000);
}

/* ---------------------------------------------------------------------
 *  Line position (28 Oct, team rule): keep the CENTRE sensor on the
 *  line and go straight while it is; the RIGHT sensor only adds a right
 *  correction.  (The C+R = centred rule zig-zagged: the line rarely
 *  covered both sensors at once.)
 *    C black, R white  ->     0   straight on
 *    C black, R black  ->  -200   line drifting right: ease right
 *    C white, R black  ->  -600   line right: steer right
 *    neither           ->  *on_line = FALSE: line_task turns back toward
 *                                 the side it was last seen (centre
 *                                 alone last = line went LEFT), then
 *                                 goes straight
 *  IR_L (barcode sensor) is passed as 0 by line_task.
 *  > 0 means the line is to the left: steer left.
 * --------------------------------------------------------------------- */
#define ERR_EASE	200
#define ERR_TURN	600

EXPORT INT line_error(INT n_l, INT n_c, INT n_r, BOOL *on_line)
{
	BOOL	l = (n_l >= LINE_BLACK_N) ? TRUE : FALSE;
	BOOL	c = (n_c >= LINE_BLACK_N) ? TRUE : FALSE;
	BOOL	r = (n_r >= LINE_BLACK_N) ? TRUE : FALSE;

	*on_line = (l || c || r) ? TRUE : FALSE;
	if (c) {
		if (r) {
			return -ERR_EASE;
		}
		if (l) {
			return ERR_EASE;
		}
		return 0;
	}
	if (r && !l) {
		return -ERR_TURN;
	}
	if (l && !r) {
		return ERR_TURN;
	}
	return 0;
}

/* ---------------------------------------------------------------------
 *  Code 39 table: 9 elements B S B S B S B S B, bit 8 = first element,
 *  1 = wide.  Every pattern has exactly three wide elements.
 * --------------------------------------------------------------------- */
typedef struct {
	UH	pattern;
	UB	ch;
} C39_ENTRY;

LOCAL const C39_ENTRY c39_table[] = {
	{0x034, '0'}, {0x121, '1'}, {0x061, '2'}, {0x160, '3'},
	{0x031, '4'}, {0x130, '5'}, {0x070, '6'}, {0x025, '7'},
	{0x124, '8'}, {0x064, '9'}, {0x109, 'A'}, {0x049, 'B'},
	{0x148, 'C'}, {0x019, 'D'}, {0x118, 'E'}, {0x058, 'F'},
	{0x00D, 'G'}, {0x10C, 'H'}, {0x04C, 'I'}, {0x01C, 'J'},
	{0x103, 'K'}, {0x043, 'L'}, {0x142, 'M'}, {0x013, 'N'},
	{0x112, 'O'}, {0x052, 'P'}, {0x007, 'Q'}, {0x106, 'R'},
	{0x046, 'S'}, {0x016, 'T'}, {0x181, 'U'}, {0x0C1, 'V'},
	{0x1C0, 'W'}, {0x091, 'X'}, {0x190, 'Y'}, {0x0D0, 'Z'},
	{0x085, '-'}, {0x184, '.'}, {0x0C4, ' '}, {0x094, '*'},
	{0x0A8, '$'}, {0x0A2, '/'}, {0x08A, '+'}, {0x02A, '%'}
};
#define C39_TABLE_LEN	(sizeof(c39_table) / sizeof(c39_table[0]))

/* Classify 9 widths into a pattern.  Returns -1 if the 3 widest are not
   clearly wider than the other 6. */
LOCAL INT c39_pattern(const UW *w, INT step)
{
	UW	sorted[9];
	UW	t;
	UW	thr;
	INT	i, j;
	INT	pat = 0;

	for (i = 0; i < 9; i++) {
		sorted[i] = w[i * step];
	}
	for (i = 1; i < 9; i++) {		/* insertion sort, descending */
		t = sorted[i];
		for (j = i - 1; (j >= 0) && (sorted[j] < t); j--) {
			sorted[j + 1] = sorted[j];
		}
		sorted[j + 1] = t;
	}
	/* narrowest wide (sorted[2]) vs widest narrow (sorted[3]) */
	if ((sorted[2] * 10U) < (sorted[3] * CODE39_MIN_RATIO_X10)) {
		return -1;
	}
	thr = (sorted[2] + sorted[3]) / 2U;
	for (i = 0; i < 9; i++) {
		pat = (pat << 1) | ((w[i * step] > thr) ? 1 : 0);
	}
	return pat;
}

LOCAL INT c39_lookup(INT pat)
{
	UINT	i;

	for (i = 0; i < C39_TABLE_LEN; i++) {
		if ((INT)c39_table[i].pattern == pat) {
			return (INT)c39_table[i].ch;
		}
	}
	return -1;
}

/* Decode in one direction: dir = +1 forwards, -1 backwards */
LOCAL INT c39_try(const UW *widths, INT dir, UB *letter)
{
	INT	c[3];
	INT	k;
	INT	pat;
	const UW *base;

	for (k = 0; k < 3; k++) {
		base = (dir > 0) ? &widths[k * 10] : &widths[CODE39_ELEMENTS - 1 - (k * 10)];
		pat = c39_pattern(base, dir);
		if (pat < 0) {
			return C39_ERR_RATIO;
		}
		c[k] = c39_lookup(pat);
		if (c[k] < 0) {
			return C39_ERR_CHAR;
		}
	}
	if ((c[0] != '*') || (c[2] != '*')) {
		return C39_ERR_STARTSTOP;
	}
	*letter = (UB)c[1];
	return C39_OK;
}

EXPORT INT code39_decode(const UW *widths, INT n, UB *letter)
{
	INT	r;

	if (n != CODE39_ELEMENTS) {
		return C39_ERR_COUNT;
	}
	r = c39_try(widths, 1, letter);
	if (r != C39_OK) {
		INT r2 = c39_try(widths, -1, letter);	/* read backwards */
		if (r2 == C39_OK) {
			return C39_OK;
		}
	}
	return r;
}

EXPORT BARCODE_CMD line_letter_to_cmd(UB letter)
{
	switch (letter) {
	case APP_BARCODE_LEFT:		return BC_TURN_LEFT;
	case APP_BARCODE_RIGHT:		return BC_TURN_RIGHT;
	case APP_BARCODE_STRAIGHT:	return BC_GO_STRAIGHT;
	case APP_BARCODE_UTURN:		return BC_U_TURN;
	default:
		break;
	}
	if ((APP_END_MARKER != '\0') && (letter == (UB)APP_END_MARKER)) {
		return BC_END_OF_COURSE;
	}
	return BC_UNRECOGNISED;	/* reported, car continues straight */
}

/* ---------------------------------------------------------------------
 *  Barcode reader
 * --------------------------------------------------------------------- */
EXPORT void bc_reader_reset(BC_READER *r)
{
	r->state = BCS_WAIT_GAP;
	r->black = FALSE;
	r->run_um = 0;
	r->n = 0;
	r->max_um = 0;
	r->samples = 0;
	r->overflow = FALSE;
}

LOCAL BC_RESULT bc_finish(BC_READER *r, UB *letter, INT *reason)
{
	BC_RESULT	res = BCR_NONE;
	INT		d;

	if (r->overflow) {
		*reason = C39_ERR_COUNT;	/* over-long read */
		res = BCR_REJECT;
	} else if (r->n == 1) {
		/* One stripe with white on both sides: a branch, not a bar */
		res = (r->widths[0] >= BC_JUNCTION_MIN_UM) ? BCR_JUNCTION : BCR_NONE;
	} else if (r->n > 1) {
		d = code39_decode(r->widths, r->n, letter);
		if (d == C39_OK) {
			res = BCR_BARCODE;
		} else {
			*reason = d;
			res = BCR_REJECT;
		}
	}
	r->state = BCS_ARMED;		/* the trailing white was a quiet zone */
	r->n = 0;
	r->max_um = 0;
	r->samples = 0;
	r->overflow = FALSE;
	return res;
}

EXPORT BC_RESULT bc_reader_feed(BC_READER *r, INT n_r, UW um,
				UB *letter, INT *reason)
{
	BOOL	level = r->black;
	UW	end_um;

	/* Threshold with hysteresis (VA2): edge noise cannot split a bar */
	if (r->black && (n_r < LINE_WHITE_N)) {
		level = FALSE;
	} else if (!r->black && (n_r > LINE_BLACK_N)) {
		level = TRUE;
	}

	if (level == r->black) {
		r->run_um += um;
	} else {
		/* An element just ended */
		if (r->state == BCS_READING) {
			if (r->n < BC_MAX_ELEMENTS) {
				r->widths[r->n++] = r->run_um;
				if (r->run_um > r->max_um) {
					r->max_um = r->run_um;
				}
			} else {
				r->overflow = TRUE;
			}
		} else if ((r->state == BCS_ARMED) && level) {
			r->state = BCS_READING;		/* first bar starts */
			r->n = 0;
			r->max_um = 0;
			r->samples = 0;
		} else {
			/* WAIT_GAP: any bar restarts the quiet-zone count */
		}
		r->black = level;
		r->run_um = um;
	}

	switch (r->state) {
	case BCS_WAIT_GAP:
		if (!r->black && (r->run_um >= BC_QUIET_MIN_UM)) {
			r->state = BCS_ARMED;
		}
		break;
	case BCS_READING:
		r->samples++;
		end_um = r->max_um * 2U;
		if (end_um < BC_QUIET_MIN_UM) {
			end_um = BC_QUIET_MIN_UM;
		}
		if (!r->black && (r->run_um >= end_um)) {
			return bc_finish(r, letter, reason);
		}
		if (r->samples > BC_MAX_SAMPLES) {
			*reason = C39_ERR_COUNT;
			bc_reader_reset(r);
			return BCR_REJECT;
		}
		break;
	default:
		break;
	}
	return BCR_NONE;
}
