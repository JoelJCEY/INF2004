/*
 *	drv_servo.h
 *	Subsystem 5 -- scan servo on GP12 (Servo port 1), PWM slice 6A, 50 Hz.
 *	Owner: scan_task only.
 */

#ifndef DRV_SERVO_H
#define DRV_SERVO_H

#include "subsystem5.h"

#define SERVO_US_0DEG		500	/* pulse at 0° (check the servo's datasheet) */
#define SERVO_US_180DEG		2500	/* pulse at 180° */
#define SERVO_SETTLE_MS		80	/* per 5-15° step before a ping */

IMPORT void drv_servo_init(void);
IMPORT void drv_servo_set_idx(UINT idx);	/* 0..24 = 30°..150° */

#endif /* DRV_SERVO_H */
