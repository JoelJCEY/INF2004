/*
 *	drv_servo.c
 *	Subsystem 5 -- 50 Hz servo PWM.  125 MHz / 40 = 3.125 MHz,
 *	62500 counts = 20 ms, so 1 µs = 3.125 counts.
 */

#include "drv_servo.h"

#define SERVO_SLICE		6U
#define SERVO_DIV_INT		40U
#define SERVO_WRAP		62499U
#define PWM_DIV_REG(s)		(PWM_BASE + ((s) * 0x14UL) + PWM_CHx_DIV)

EXPORT void drv_servo_init(void)
{
	app_unreset(RESETS_RESET_PWM);
	pwm_set_pin(SERVO_PIN);
	out_w(PWM_DIV_REG(SERVO_SLICE), SERVO_DIV_INT << 4);	/* 8.4 fixed point */
	pwm_set_wrap(SERVO_PIN, SERVO_WRAP);
	drv_servo_set_idx(SERVO_CENTRE_IDX);
	pwm_set_enabled(SERVO_PIN, TRUE);
}

EXPORT void drv_servo_set_idx(UINT idx)
{
	UW	deg = (UW)SERVO_IDX_TO_DEG((idx > 24U) ? 24U : idx);
	UW	us = SERVO_US_0DEG + ((deg * (SERVO_US_180DEG - SERVO_US_0DEG)) / 180U);

	pwm_set_cc(SERVO_PIN, (us * 25U) / 8U);	/* x 3.125 */
	scan_status_word = (scan_status_word & ~0x1FUL) | (idx & 0x1FUL);
}
