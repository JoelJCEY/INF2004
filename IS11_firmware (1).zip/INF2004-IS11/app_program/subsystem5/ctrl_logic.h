/*
 *	ctrl_logic.h
 *	Subsystem 5 -- pure parts of the Vehicle Controller (no kernel
 *	calls), unit-tested in subsystem5_test.c: which states accept which
 *	command, and how a profile becomes a list of bypass legs.
 */

#ifndef CTRL_LOGIC_H
#define CTRL_LOGIC_H

#include "subsystem5.h"

/* Is the state an "active manoeuvre" one (STOP / impact apply)? */
IMPORT BOOL ctrl_is_active(VEHICLE_STATE s);
/* Next state for a START / STOP / RESET in state s, or s if rejected. */
IMPORT VEHICLE_STATE ctrl_on_command(VEHICLE_STATE s, REMOTE_CMD c);
/* Next state for newly reported faults (FLT_xxx) in state s. */
IMPORT VEHICLE_STATE ctrl_on_faults(VEHICLE_STATE s, UINT faults);

/* ---------------------------------------------------------------------
 *  Manoeuvre steps executed one at a time through the motion API
 * --------------------------------------------------------------------- */
typedef enum {
	STEP_TURN	= 1,	/* arg: signed degrees, + = left            */
	STEP_MOVE	= 2,	/* arg: signed mm                           */
	STEP_SEARCH	= 3,	/* arg: mm; ends early when the line is seen */
	STEP_SEARCH_TURN = 4	/* arg: signed degrees; ends early on the line */
} STEP_OP;

typedef struct {
	UB	op;
	W	arg;
} CTRL_STEP;

#define CTRL_MAX_STEPS		8
#define CTRL_SEARCH_EXTRA_MM	150	/* search past the expected line */
#define CTRL_REVERSE_MM		100	/* before a rescan               */
#define CTRL_BYPASS_BACKUP_MM	100	/* reverse before going around (28 Oct):
					   at a 10 cm stop the car cannot turn
					   without touching the obstacle */
#define CTRL_BARCODE_OFFSET_MM	0	/* execution point: to confirm (FR2) */

/* Rectangular detour (Version A approach, 5): turn out, move across,
   turn parallel, pass, turn back, search for the line, re-align. */
IMPORT INT ctrl_plan_bypass(UB side, W offset_mm, W depth_mm, CTRL_STEP *steps);
/* Barcode command -> steps (0 steps: just keep following) */
IMPORT INT ctrl_plan_barcode(BARCODE_CMD cmd, CTRL_STEP *steps);

#endif /* CTRL_LOGIC_H */
