/*
 *	drv_ultrasonic.c
 *	Subsystem 5 -- HC-SR04+ driver (TRIG GP0, ECHO GP1), echo timed by
 *	polling (see below).
 *
 *	us_echo_word: last raw result for diagnostics, one aligned 32-bit
 *	store, written by scan_task only.
 */

#include "drv_ultrasonic.h"

EXPORT volatile UW us_echo_word;

/* 28 Oct: the echo is timed by POLLING GP1 in scan_task, not by the
   GPIO interrupt.  Measured on the car: interrupt latency was often
   over 1 ms (both edges of a short echo then arrive together and the
   pulse looks ~0 mm long), which produced phantom obstacles a few cm
   away.  The ultrasonic diagnostic (us_diag.c) times by polling and
   read 357-378 mm for a hand at 37 cm.  scan_task (priority 13) busy-
   waits at most ~6.2 ms per ping; higher-priority tasks still run. */
#define ECHO_START_MAX_US	2000U	/* echo must start within 2 ms */

EXPORT ER drv_us_init(void)
{
	/* TRIG: plain SIO output (GP0 is UART0 TX only in CRASH_REPORT builds) */
	gpio_set_pin(US_TRIG_PIN, GPIO_MODE_OUT);
	gpio_set_val(US_TRIG_PIN, 0);
	/* ECHO: SIO input, pull-down so a missing module reads "no echo" */
	gpio_set_pin(US_ECHO_PIN, GPIO_MODE_IN);
	set_w(GPIO(US_ECHO_PIN), GPIO_PDE);
	us_echo_word = 0;
	return E_OK;
}

EXPORT UW drv_us_dur_to_mm(UW dur_us)
{
	/* mm = µs * 0.343 / 2 */
	return (dur_us * 343UL) / 2000UL;
}

EXPORT US_RESULT drv_us_ping(UW *mm)
{
	UW	t0;
	UW	tr;
	UW	dur;

	/* An HC-SR04+ that heard nothing keeps ECHO high for ~59 ms; a
	   trigger then is ignored: report "far" and do not trigger */
	if (gpio_get_val(US_ECHO_PIN) != 0U) {
		return US_FAR;
	}

	/* Timed at scan_task's own priority (13): motion (11), line (12) and
	   ctrl (10) keep running on time.  28 Oct: an earlier version
	   disabled task switching here for up to 8 ms per ping, which
	   delayed line following; removed.  A preemption can only make a
	   pulse look LONGER (= farther), never a phantom close obstacle. */
	gpio_set_val(US_TRIG_PIN, 1);
	app_delay_us(10);			/* 10 µs trigger pulse */
	gpio_set_val(US_TRIG_PIN, 0);
	t0 = app_time_us();

	while (gpio_get_val(US_ECHO_PIN) == 0U) {
		if ((app_time_us() - t0) > ECHO_START_MAX_US) {
			return US_NO_ECHO;	/* ECHO never rose */
		}
	}
	tr = app_time_us();
	while (gpio_get_val(US_ECHO_PIN) != 0U) {
		if ((app_time_us() - tr) > ECHO_TIMEOUT_US) {
			return US_FAR;		/* nothing within ~1 m: normal */
		}
	}
	dur = app_time_us() - tr;
	us_echo_word = ECHO_VALID | (dur & ECHO_DUR_MASK);	/* diagnostics */
	*mm = drv_us_dur_to_mm(dur);
	return US_OK;
}
