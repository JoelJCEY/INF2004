/*
 *	comms_bridge.c
 *	Subsystem 1 -- code that runs inside the kernel's Wi-Fi service task
 *	(called from mqtt_utk.c).  TMO_POL only; no mutex is ever taken.
 */

#include "subsystem1.h"
#include "comms_bridge.h"
#include "../subsystem5/subsystem5.h"	/* IF-03 mbf_remote, flg_sys */

EXPORT volatile UW comms_mqtt_connected;	/* writer: Wi-Fi task (bridge) */
EXPORT volatile UW comms_rx_rejected;

int comms_bridge_take_frame(unsigned char *buf, int max)
{
	UB	frame[WIRE_TLM_LEN];
	INT	n;
	INT	i;

	if ((mbf_outbox <= 0) || (max < WIRE_TLM_LEN)) {
		return 0;
	}
	n = tk_rcv_mbf(mbf_outbox, frame, TMO_POL);
	if (n <= 0) {
		return 0;
	}
	for (i = 0; i < n; i++) {
		buf[i] = frame[i];
	}
	return (int)n;
}

void comms_bridge_on_command(const unsigned char *data, int len)
{
	REMOTE_MSG	m;

	if ((mbf_remote <= 0) || (comms_decode_cmd(data, (INT)len, &m) != E_OK)) {
		comms_rx_rejected++;
		tm_printf((UB*)"comms: command rejected (len %d)\n", len);
		return;
	}
	/* STOP is the latency-critical message: forwarded at once, from
	   here, without waiting for comms_task's next cycle (6.1) */
	if (tk_snd_mbf(mbf_remote, &m, sizeof(m), TMO_POL) < E_OK) {
		comms_rx_rejected++;
		return;
	}
	(void)tk_set_flg(flg_sys, EVF_REMOTE);
}

void comms_bridge_set_connected(int connected)
{
	comms_mqtt_connected = (connected != 0) ? 1U : 0U;
}
