/*
 *	comms_bridge.h
 *	Subsystem 1 -- functions the MQTT client (lib/liblwip/sysdepend/
 *	pico_rp2040/mqtt_utk.c) calls from INSIDE the kernel's Wi-Fi service
 *	task.  Plain C types only and no includes, because mqtt_utk.c mixes
 *	lwIP headers that must not meet tk/tkernel.h (size_t clash).
 *
 *	Every function returns at once: kernel calls inside use TMO_POL, so
 *	a slow application can never stall the radio (NFR3).
 *	mqtt_utk.c has weak no-op versions, so the library builds alone.
 */

#ifndef COMMS_BRIDGE_H
#define COMMS_BRIDGE_H

/* Copy the oldest encoded telemetry frame into buf.  Returns its length,
   or 0 when the outbox is empty. */
int  comms_bridge_take_frame(unsigned char *buf, int max);

/* A complete message arrived on the command topic (raw bytes). */
void comms_bridge_on_command(const unsigned char *data, int len);

/* MQTT session up (1) or down (0). */
void comms_bridge_set_connected(int connected);

#endif /* COMMS_BRIDGE_H */
