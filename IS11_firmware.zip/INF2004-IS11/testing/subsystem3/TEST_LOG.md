# Subsystem 3 (Line & Barcode) — test log

**Owner:** Buddy 3, 2500991 (Gillton)  ·  **Code:** `app_program/subsystem3/`

See `testing/README.md` for how to run tests and record results.
Nothing has been measured yet: every target below comes from the IS11 Design Review.

## Test cases

Define a test here before running it. Test IDs never change.

| ID | What is tested | Requirement / interface | Method | Steps / how | Expected result |
|---|---|---|---|---|---|
| S3-U01 | '*A*' decodes forwards | FR2 | auto | `subsystem3_test.c` | PASS |
| S3-U02 | '*A*' decodes backwards | FR2, 6.3 | auto | `subsystem3_test.c` | PASS |
| S3-U03 | 28-element read rejected | VA2 | auto | `subsystem3_test.c` | PASS |
| S3-U04 | letter-to-command mapping | FR2 | auto | `subsystem3_test.c` | PASS |
| S3-U05 | reader decodes '*Z*' from 1 kHz samples at 0.3 m/s | NFR1 | auto | `subsystem3_test.c` | PASS |
| S3-U06 | 18 mm single stripe is a junction | F3, A3 | auto | `subsystem3_test.c` | PASS |
| S3-U07a-c | line error sign and packing | IF-08 | auto | `subsystem3_test.c` | PASS |
| S3-U08 | DMA ring write index advances | NFR1 | auto | `subsystem3_test.c` | PASS |
| S3-M01 | raw ADC levels on black, white, barcodes at 0.15/0.3/0.5 m/s | A3 | manual | Log `line_latest` + console; vary room lighting | black/white separate by ≥ 800 counts; set LINE_DEF_* |
| S3-M02 | barcode decode rate | NFR1, A3 | manual | 20 passes per barcode, both directions, each sample size | ≥ 95 % correct |
| S3-M03 | tightest curve at 0.3 m/s | FR1, F9 | manual | 10 laps | no LINE LOST |
| S3-M04 | line lost after 200 mm | 6.3, 5.1 | manual | Lift the car off the line while rolling | STOPPED after ~200 mm, FLT_LINE_LOST |

*Method:* **auto** = `TEST_CHECK` in code, result printed on the console
(`make SMP=0 NET=lwip MQTT=1 TEST=1 -j8`); **manual** = a person observes or
measures the result (scope, ruler, stopwatch, video).

## Results

Add a new row for every run. Never edit or delete old rows.

| Date | Test ID | Commit | Tester | Result | Log / evidence | Notes |
|---|---|---|---|---|---|---|
| YYYY-MM-DD | | `abc1234` | | PASS / FAIL | `logs/YYYY-MM-DD_….txt` | |
