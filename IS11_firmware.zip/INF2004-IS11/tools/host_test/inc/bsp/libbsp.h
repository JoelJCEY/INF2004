#ifndef HOST_BSP_H
#define HOST_BSP_H
#define IO_BANK0_BASE 0x40014000UL
#define GPIO(n) (0x4001c000UL + 4UL + (n) * 4UL)
#define GPIO_PDE (1 << 2)
#define GPIO_PUE (1 << 3)
#define GPIO_MODE_OUT 1
#define GPIO_MODE_IN 2
ER gpio_set_pin(UINT no, UINT mode); ER gpio_set_val(UINT no, UINT val);
UINT gpio_get_val(UINT no);
#endif
